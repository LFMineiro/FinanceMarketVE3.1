#ifndef MENU_H
#define MENU_H

int showMenu();
void processOption(int option);

#endif

